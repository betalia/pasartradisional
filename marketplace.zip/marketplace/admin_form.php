<?php require 'inc.php';if(empty($_SESSION['admin'])){header('Location: admin.php');exit;}
$id=(int)($_GET['id']??0);$p=['name'=>'','description'=>'','price'=>'','stock'=>'','seller_id'=>1,'category_id'=>1];
if($id){$s=$db->prepare("SELECT * FROM products WHERE id=?");$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $a=[$_POST['seller_id'],$_POST['category_id'],$_POST['name'],$_POST['description'],$_POST['price'],$_POST['stock']];
 if($id){$s=$db->prepare("UPDATE products SET seller_id=?,category_id=?,name=?,description=?,price=?,stock=? WHERE id=?");$s->bind_param('iissdii',...[...$a,$id]);}
 else{$s=$db->prepare("INSERT INTO products(seller_id,category_id,name,description,price,stock) VALUES(?,?,?,?,?,?)");$s->bind_param('iissdi',...$a);}
 $s->execute();header('Location: admin.php');exit;}
top('Form Produk');
function opt($db,$t,$sel){$o='';$r=$db->query("SELECT id,name FROM $t");while($x=$r->fetch_assoc())$o.='<option value="'.$x['id'].'"'.($x['id']==$sel?' selected':'').'>'.h($x['name']).'</option>';return $o;}?>
<h4><?=$id?'Edit':'Tambah'?> Produk</h4><form method="post" class="card card-body">
<input name="name" class="form-control mb-2" placeholder="Nama" value="<?=h($p['name'])?>" required>
<select name="seller_id" class="form-select mb-2"><?=opt($db,'sellers',$p['seller_id'])?></select>
<select name="category_id" class="form-select mb-2"><?=opt($db,'categories',$p['category_id'])?></select>
<textarea name="description" class="form-control mb-2" placeholder="Deskripsi"><?=h($p['description'])?></textarea>
<input name="price" type="number" step="0.01" class="form-control mb-2" placeholder="Harga" value="<?=h($p['price'])?>" required>
<input name="stock" type="number" class="form-control mb-2" placeholder="Stok" value="<?=h($p['stock'])?>" required>
<button class="btn btn-success">Simpan</button></form><?php bottom();
