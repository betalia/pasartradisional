CREATE TABLE sellers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,phone VARCHAR(20),city VARCHAR(60));
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(60) NOT NULL);
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,seller_id INT NOT NULL,category_id INT NOT NULL,name VARCHAR(120) NOT NULL,description TEXT,price DECIMAL(12,2) NOT NULL,stock INT NOT NULL DEFAULT 0,image VARCHAR(255),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(seller_id) REFERENCES sellers(id),FOREIGN KEY(category_id) REFERENCES categories(id));
CREATE TABLE customers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(100),phone VARCHAR(20),address TEXT NOT NULL);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,total DECIMAL(12,2) NOT NULL,status ENUM('pending','paid','shipped','done') DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(id));
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,product_id INT NOT NULL,qty INT NOT NULL,price DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(product_id) REFERENCES products(id));
INSERT INTO sellers(name,phone,city) VALUES('Toko Sari Pasar','08123456789','Bengkulu'),('UD Tani Makmur','08129876543','Bengkulu');
INSERT INTO categories(name) VALUES('Sayuran'),('Buah'),('Kerajinan'),('Makanan Olahan');
INSERT INTO products(seller_id,category_id,name,description,price,stock) VALUES
(1,1,'Cabai Merah 1 kg','Cabai merah segar dari petani lokal.',45000,50),
(1,2,'Pisang Kepok 1 sisir','Pisang kepok matang pohon.',20000,30),
(2,4,'Kerupuk Ikan 500 g','Kerupuk ikan khas pesisir.',30000,40),
(2,3,'Tas Anyaman Pandan','Tas anyaman tangan.',85000,10);
