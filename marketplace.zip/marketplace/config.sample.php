<?php
// Salin menjadi config.php lalu isi sesuai hosting. JANGAN commit config.php.
$DB = ['host'=>'sqlXXX.infinityfree.com','user'=>'if0_XXXXXXX','pass'=>'ISI_PASSWORD','name'=>'if0_XXXXXXX_marketplace'];
$ADMIN_PASSWORD = 'ganti_password_admin';
