<?php require 'inc.php'; top('Daftar Produk');
$q='%'.($_GET['q']??'').'%';
$s=$db->prepare("SELECT p.*,c.name cat,s.name seller FROM products p JOIN categories c ON c.id=p.category_id JOIN sellers s ON s.id=p.seller_id WHERE p.name LIKE ? ORDER BY p.id DESC");
$s->bind_param('s',$q);$s->execute();$r=$s->get_result();?>
<form class="d-flex mb-3"><input name="q" class="form-control me-2" placeholder="Cari produk..." value="<?=h($_GET['q']??'')?>"><button class="btn btn-success">Cari</button></form>
<div class="row"><?php while($p=$r->fetch_assoc()):?>
<div class="col-6 col-md-3 mb-3"><div class="card h-100"><div class="card-body">
<span class="badge bg-secondary"><?=h($p['cat'])?></span>
<h6 class="mt-2"><?=h($p['name'])?></h6><small class="text-muted"><?=h($p['seller'])?></small>
<p class="fw-bold text-success mb-2"><?=rp($p['price'])?></p>
<a class="btn btn-sm btn-outline-success" href="product.php?id=<?=$p['id']?>">Detail</a></div></div></div>
<?php endwhile;?></div><?php bottom();
