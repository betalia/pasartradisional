# Marketplace Tradisional (PHP Native + MySQLi + Bootstrap)

## A. Analisis & Perancangan
**Entitas (6):** sellers, categories, products, customers, orders, order_items.

**Tabel & relasi** (PK = id; FK tercantum di db.sql):
| Tabel | Atribut utama | FK |
|---|---|---|
| sellers | id, name, phone, city | - |
| categories | id, name | - |
| products | id, name, description, price, stock, image, created_at | seller_id→sellers, category_id→categories |
| customers | id, name, email, phone, address | - |
| orders | id, total, status, created_at | customer_id→customers |
| order_items | id, qty, price | order_id→orders, product_id→products |

Relasi: seller 1—N products; category 1—N products; customer 1—N orders; order 1—N order_items; product 1—N order_items (order_items = tabel penghubung N:M orders–products).

## ERD
```mermaid
erDiagram
 sellers ||--o{ products : menjual
 categories ||--o{ products : mengelompokkan
 customers ||--o{ orders : membuat
 orders ||--|{ order_items : berisi
 products ||--o{ order_items : dipesan
 sellers { int id PK string name string phone string city }
 categories { int id PK string name }
 products { int id PK int seller_id FK int category_id FK string name decimal price int stock }
 customers { int id PK string name string email string phone text address }
 orders { int id PK int customer_id FK decimal total enum status }
 order_items { int id PK int order_id FK int product_id FK int qty decimal price }
```

## Alur Transaksi
Pembeli buka daftar produk → detail produk → tambah ke keranjang (session) → ubah/hapus qty → checkout → isi data pemesan → BEGIN transaksi: simpan customer, cek stok (lock), simpan orders + order_items, kurangi stok → COMMIT (jika gagal: ROLLBACK) → tampil nomor pesanan.

## Mockup UI (wireframe)
```
DAFTAR PRODUK                DETAIL PRODUK               KERANJANG
[Pasar Online][Admin][Krj]   [Pasar Online][Admin][Krj]  [Pasar Online][Admin][Krj]
[Cari........][Cari]         Cabai Merah 1 kg            Produk |Harga|Qty|Sub |
+------+ +------+ +------+   Kategori·Penjual          Cabai  |45rb |[2]|90rb|[Hapus]
|Nama  | |Nama  | |Nama  |   Deskripsi...              Total: Rp 90.000
|Rp... | |Rp... | |Rp... |   Rp 45.000  Stok: 50       [Checkout]
|[Detail] ...              [qty][Tambah ke Keranjang]
```

## B. Menjalankan lokal
1. Buat database `marketplace`, import `db.sql`.
2. Salin `config.sample.php` → `config.php`, isi kredensial.
3. Taruh folder di htdocs, buka `index.php`. Admin: `admin.php`.

## C. Deploy InfinityFree
1. Daftar di infinityfree.com → buat akun hosting → catat subdomain.
2. Control Panel → MySQL Databases → buat database; catat host (sqlXXX.infinityfree.com), user, nama DB.
3. phpMyAdmin → import `db.sql`.
4. File Manager/FTP → upload semua file (kecuali .git) ke `htdocs/`, buat `config.php` di server dengan kredensial hosting.
5. Uji di URL subdomain: tambah produk, checkout, cek tabel orders.

## D. GitHub
```
git init && git add . && git commit -m "Marketplace PHP"
git remote add origin https://github.com/USERNAME/marketplace.git
git push -u origin main
```
`config.php` sudah masuk `.gitignore`; hanya `config.sample.php` yang diunggah.

## Laporan — isi setelah deploy
- URL demo: ...
- URL GitHub: ...
- Screenshot: aplikasi, struktur database (phpMyAdmin), hasil transaksi (tabel orders & order_items).
