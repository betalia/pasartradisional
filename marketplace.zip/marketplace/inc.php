<?php
session_start();
require __DIR__.'/config.php';
mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
$db=new mysqli($DB['host'],$DB['user'],$DB['pass'],$DB['name']);
$db->set_charset('utf8mb4');
function h($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function rp($n){return 'Rp '.number_format($n,0,',','.');}
function top($t='Marketplace'){$c=array_sum($_SESSION['cart']??[]);
echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($t).'</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light">
<nav class="navbar navbar-dark bg-success mb-4"><div class="container"><a class="navbar-brand" href="index.php">Pasar Online</a>
<div><a class="btn btn-outline-light btn-sm" href="admin.php">Admin</a> <a class="btn btn-light btn-sm" href="cart.php">Keranjang ('.$c.')</a></div></div></nav><div class="container">';}
function bottom(){echo '</div></body></html>';}
