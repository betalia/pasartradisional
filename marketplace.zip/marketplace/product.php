<?php require 'inc.php'; top('Detail Produk');
$s=$db->prepare("SELECT p.*,c.name cat,s.name seller,s.city FROM products p JOIN categories c ON c.id=p.category_id JOIN sellers s ON s.id=p.seller_id WHERE p.id=?");
$id=(int)($_GET['id']??0);$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();
if(!$p){echo '<div class="alert alert-danger">Produk tidak ditemukan.</div>';bottom();exit;}?>
<div class="card"><div class="card-body"><h3><?=h($p['name'])?></h3>
<p class="text-muted"><?=h($p['cat'])?> · Penjual: <?=h($p['seller'])?> (<?=h($p['city'])?>)</p>
<p><?=nl2br(h($p['description']))?></p><h4 class="text-success"><?=rp($p['price'])?></h4><p>Stok: <?=$p['stock']?></p>
<form method="post" action="cart.php" class="d-flex gap-2"><input type="hidden" name="act" value="add"><input type="hidden" name="id" value="<?=$p['id']?>">
<input type="number" name="qty" value="1" min="1" max="<?=$p['stock']?>" class="form-control w-25"><button class="btn btn-success" <?=$p['stock']<1?'disabled':''?>>Tambah ke Keranjang</button></form></div></div>
<?php bottom();
