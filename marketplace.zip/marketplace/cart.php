<?php require 'inc.php';
$c=&$_SESSION['cart'];$c=$c??[];
if($_SERVER['REQUEST_METHOD']==='POST'){$id=(int)$_POST['id'];$q=max(1,(int)($_POST['qty']??1));
 if($_POST['act']==='add')$c[$id]=($c[$id]??0)+$q;
 if($_POST['act']==='set')$c[$id]=$q;
 if($_POST['act']==='del')unset($c[$id]);
 header('Location: cart.php');exit;}
top('Keranjang');$total=0;?>
<h4>Keranjang Belanja</h4>
<?php if(!$c):?><div class="alert alert-info">Keranjang kosong.</div><?php else:?>
<table class="table bg-white"><tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Subtotal</th><th></th></tr>
<?php foreach($c as $id=>$q):$s=$db->prepare("SELECT name,price FROM products WHERE id=?");$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();if(!$p)continue;$sub=$p['price']*$q;$total+=$sub;?>
<tr><td><?=h($p['name'])?></td><td><?=rp($p['price'])?></td>
<td><form method="post" class="d-flex gap-1"><input type="hidden" name="act" value="set"><input type="hidden" name="id" value="<?=$id?>"><input type="number" name="qty" value="<?=$q?>" min="1" class="form-control form-control-sm" style="width:70px"><button class="btn btn-sm btn-outline-secondary">Ubah</button></form></td>
<td><?=rp($sub)?></td><td><form method="post"><input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?=$id?>"><button class="btn btn-sm btn-danger">Hapus</button></form></td></tr>
<?php endforeach;?>
<tr><th colspan="3" class="text-end">Total</th><th colspan="2"><?=rp($total)?></th></tr></table>
<a class="btn btn-success" href="checkout.php">Checkout</a><?php endif; bottom();
