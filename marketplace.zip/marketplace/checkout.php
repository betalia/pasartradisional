<?php require 'inc.php';
$c=$_SESSION['cart']??[];if(!$c){header('Location: cart.php');exit;}
$err='';$oid=0;
if($_SERVER['REQUEST_METHOD']==='POST'){
 $db->begin_transaction();
 try{
  $s=$db->prepare("INSERT INTO customers(name,email,phone,address) VALUES(?,?,?,?)");
  $s->bind_param('ssss',$_POST['name'],$_POST['email'],$_POST['phone'],$_POST['address']);$s->execute();$cid=$db->insert_id;
  $items=[];$total=0;
  foreach($c as $id=>$q){
   $s=$db->prepare("SELECT price,stock FROM products WHERE id=? FOR UPDATE");$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();
   if(!$p||$p['stock']<$q)throw new Exception("Stok produk #$id tidak cukup.");
   $items[]=[$id,$q,$p['price']];$total+=$p['price']*$q;}
  $s=$db->prepare("INSERT INTO orders(customer_id,total) VALUES(?,?)");$s->bind_param('id',$cid,$total);$s->execute();$oid=$db->insert_id;
  foreach($items as [$id,$q,$pr]){
   $s=$db->prepare("INSERT INTO order_items(order_id,product_id,qty,price) VALUES(?,?,?,?)");$s->bind_param('iiid',$oid,$id,$q,$pr);$s->execute();
   $s=$db->prepare("UPDATE products SET stock=stock-? WHERE id=?");$s->bind_param('ii',$q,$id);$s->execute();}
  $db->commit();$_SESSION['cart']=[];
 }catch(Exception $e){$db->rollback();$err=$e->getMessage();}
}
top('Checkout');
if($oid):?><div class="alert alert-success">Pesanan berhasil dibuat. Nomor pesanan: <b>#<?=$oid?></b></div><a href="index.php" class="btn btn-success">Kembali belanja</a>
<?php else:if($err)echo '<div class="alert alert-danger">'.h($err).'</div>';?>
<h4>Data Pemesan</h4><form method="post" class="card card-body">
<input name="name" class="form-control mb-2" placeholder="Nama" required><input name="email" type="email" class="form-control mb-2" placeholder="Email">
<input name="phone" class="form-control mb-2" placeholder="No. HP" required><textarea name="address" class="form-control mb-2" placeholder="Alamat" required></textarea>
<button class="btn btn-success">Buat Pesanan</button></form><?php endif;bottom();
