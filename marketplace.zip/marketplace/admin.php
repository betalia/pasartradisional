<?php require 'inc.php';
if(isset($_POST['pw'])&&hash_equals($ADMIN_PASSWORD,$_POST['pw']))$_SESSION['admin']=1;
if(isset($_GET['logout'])){unset($_SESSION['admin']);header('Location: admin.php');exit;}
top('Admin');
if(empty($_SESSION['admin'])){echo '<form method="post" class="card card-body" style="max-width:360px"><input type="password" name="pw" class="form-control mb-2" placeholder="Password admin"><button class="btn btn-success">Login</button></form>';bottom();exit;}
if(isset($_POST['del'])){$s=$db->prepare("DELETE FROM products WHERE id=?");$d=(int)$_POST['del'];$s->bind_param('i',$d);
 try{$s->execute();}catch(Exception $e){echo '<div class="alert alert-warning">Produk sudah ada di pesanan, tidak bisa dihapus.</div>';}}
$r=$db->query("SELECT p.*,c.name cat FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC");?>
<div class="d-flex justify-content-between mb-2"><h4>Kelola Produk</h4><div><a class="btn btn-success btn-sm" href="admin_form.php">+ Tambah</a> <a class="btn btn-secondary btn-sm" href="?logout=1">Logout</a></div></div>
<table class="table bg-white"><tr><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th></th></tr>
<?php while($p=$r->fetch_assoc()):?><tr><td><?=h($p['name'])?></td><td><?=h($p['cat'])?></td><td><?=rp($p['price'])?></td><td><?=$p['stock']?></td>
<td><a class="btn btn-sm btn-warning" href="admin_form.php?id=<?=$p['id']?>">Edit</a>
<form method="post" class="d-inline" onsubmit="return confirm('Hapus?')"><input type="hidden" name="del" value="<?=$p['id']?>"><button class="btn btn-sm btn-danger">Hapus</button></form></td></tr><?php endwhile;?></table>
<?php bottom();
